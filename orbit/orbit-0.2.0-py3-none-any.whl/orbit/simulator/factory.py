"""Factory functions for creating simulation models and configurations."""

import numpy as np

from .config import ControllerConfig, ReplicaConfig, SimulationConfig
from .models import (
    BiasCalculatorModel,
    ControllerModel,
    NetworkModel,
    SimulationModel,
)


def create_ising_simulation(
    coupling_matrix: np.ndarray,
    external_field: np.ndarray,
    n_replicas: int = 10,
    max_full_sweeps: int = 1000,
    max_processes: int = 1,
    **kwargs,
) -> tuple[SimulationModel, SimulationConfig]:
    """
    Create a complete simulation setup for Ising model problems.

    Args:
        coupling_matrix: J matrix for Ising interactions
        external_field: h vector for external fields
        n_replicas: Number of replicas to run
        max_full_sweeps: Maximum iterations per replica
        max_processes: Number of processes for parallel execution
        **kwargs: Additional configuration parameters

    Returns:
        Tuple of (SimulationModel, SimulationConfig)
    """
    from .components.bias_calculators.ising_calculator import IsingCalculator
    # TODO: Check coupling matrix and external field input sizes and that J is symmetrical

    n_nodes = len(external_field)

    # Generate adjacency dictionary from coupling matrix
    adjacency = {}
    for i in range(n_nodes):
        neighbors = set()
        for j, val in enumerate(coupling_matrix[i]):
            if val != 0:
                neighbors.add(j)
        adjacency[i] = neighbors

    # Find update group for each p-bit using greedy algorithm
    update_groups = np.full(n_nodes, -1, dtype="int16")
    for i, neighbors in adjacency.items():
        neighbor_colors = set()
        for neighbor_idx in neighbors:
            if update_groups[neighbor_idx] != -1:
                neighbor_colors.add(update_groups[neighbor_idx])
        active_color = 0
        while active_color in neighbor_colors:
            active_color += 1
        update_groups[i] = active_color

    network_model = NetworkModel(adjacency=adjacency, update_groups=update_groups)

    # Create bias calculator model with IsingCalculator
    bias_calculator_model = BiasCalculatorModel(
        calculator_class=IsingCalculator,
        calculator_args=(coupling_matrix, external_field),
        calculator_kwargs={},
    )

    controller_model = ControllerModel(
        bias_calculator_model=bias_calculator_model,
        network_model=network_model,
    )

    simulation_model = SimulationModel(controller_model=controller_model)

    replica_config = ReplicaConfig(
        max_full_sweeps=max_full_sweeps,
        **{k: v for k, v in kwargs.items() if k in ReplicaConfig.model_fields},
    )

    controller_config = ControllerConfig(
        n_replicas=n_replicas,
        max_processes=max_processes,
        replica_config=replica_config,
    )

    simulation_config = SimulationConfig(
        controller_config=controller_config,
        **{k: v for k, v in kwargs.items() if k in SimulationConfig.model_fields},
    )

    return simulation_model, simulation_config


def create_example_simulation() -> tuple[SimulationModel, SimulationConfig]:
    """
    Create an example simulation setup for demonstration purposes.

    Returns:
        Tuple of (SimulationModel, SimulationConfig)
    """
    # Simple 3-node Ising problem
    coupling_matrix = np.array([[0.0, 1.0, -1.0], [1.0, 0.0, 1.0], [-1.0, 1.0, 0.0]])

    external_field = np.array([0.5, -0.5, 0.0])

    return create_ising_simulation(
        coupling_matrix=coupling_matrix,
        external_field=external_field,
        n_replicas=5,
        max_full_sweeps=500,
    )
