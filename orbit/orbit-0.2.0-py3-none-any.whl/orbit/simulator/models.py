import inspect
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .components.base import AbstractBiasCalculator


class NetworkModel(BaseModel):
    """Configuration for network topology and structure."""

    adjacency: dict[int, set[int]] = Field(
        ..., description="Adjacency list representing connections between pbits"
    )
    update_groups: list[int] = Field(
        ..., description="List containing the update group for each pbit"
    )

    @field_validator("adjacency")
    @classmethod
    def validate_adjacency(cls, v: dict[int, set[int]]) -> dict[int, set[int]]:
        """Validate adjacency structure."""
        if not v:
            raise ValueError("Adjacency dictionary cannot be empty")

        max_node = max(v.keys())
        expected_nodes = set(range(max_node + 1))
        actual_nodes = set(v.keys())

        if actual_nodes != expected_nodes:
            raise ValueError(
                f"Adjacency must contain consecutive node IDs from 0 to {max_node}"
            )

        # Validate that referenced neighbors exist
        for node, neighbors in v.items():
            invalid_neighbors = neighbors - actual_nodes
            if invalid_neighbors:
                raise ValueError(
                    f"Node {node} references non-existent neighbors: {invalid_neighbors}"
                )

        return v

    @field_validator("update_groups")
    @classmethod
    def validate_update_groups(cls, v: list[int]) -> list[int]:
        """Validate update groups structure."""
        if not v:
            raise ValueError("Update groups list cannot be empty")

        if min(v) < 0:
            raise ValueError("Update group indices must be non-negative")

        return v

    @model_validator(mode="after")
    def validate_consistency(self) -> "NetworkModel":
        """Validate consistency between adjacency and update groups."""
        n_nodes = len(self.adjacency)
        if len(self.update_groups) != n_nodes:
            raise ValueError(
                f"Update groups length ({len(self.update_groups)}) "
                f"must match number of nodes ({n_nodes})"
            )

        return self


class BiasCalculatorModel(BaseModel):
    calculator_class: type[AbstractBiasCalculator] = Field(
        ..., description="Class of bias calculator"
    )
    calculator_args: tuple[Any, ...] = Field(
        default=(), description="Positional arguments for calculator initialization"
    )
    calculator_kwargs: dict[str, Any] = Field(
        default_factory=dict,
        description="Keyword arguments for calculator initialization",
    )
    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_validator("calculator_class")
    @classmethod
    def must_be_subclass(cls, v):
        if not inspect.isclass(v):
            raise TypeError("calculator_class must be a class type.")
        if not issubclass(v, AbstractBiasCalculator):
            raise TypeError(
                "calculator_class must be a subclass of AbstractBiasCalculator."
            )
        # if inspect.isabstract(v):
        #     raise TypeError("calculator_class must be a concrete (non-abstract) subclass.")
        return v

    def instantiate(self) -> AbstractBiasCalculator:
        """Instantiate the bias calculator with stored arguments."""
        return self.calculator_class(*self.calculator_args, **self.calculator_kwargs)


class ControllerModel(BaseModel):
    """Configuration for controller component."""

    bias_calculator_model: BiasCalculatorModel = Field(
        ..., description="Bias calculator model"
    )

    network_model: NetworkModel = Field(..., description="Network model")


class SimulationModel(BaseModel):
    """Main model for ORBIT simulations"""

    controller_model: ControllerModel = Field(..., description="Controller model")


class SimulationResult(BaseModel):
    """Results from a completed simulation."""

    samples: list[np.ndarray] = Field(..., description="Samples from each replica")
    # config: SimulationConfig = Field(
    #     ..., description="Configuration used for this simulation"
    # )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata about the simulation"
    )

    # Statistics
    iterations: list[int] | None = Field(
        default=None, description="Iterations completed by each replica"
    )
    full_sweeps: list[int] | None = Field(
        default=None, description="Full sweeps completed by each replica"
    )
    parallel_bias_calculations: list[int] | None = Field(
        default=None,
        description="Number of parallel bias calculations completed by each replica",
    )
    execution_time: float | None = Field(
        default=None, description="Total execution time in seconds"
    )

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def get_combined_samples(self) -> np.ndarray:
        """Combine samples from all replicas into a single array."""
        return np.concatenate(self.samples, axis=0)

    def get_sample_statistics(self) -> dict[str, Any]:
        """Calculate basic statistics across all samples."""
        combined = self.get_combined_samples()
        return {
            "mean": combined.mean(axis=0),
            "std": combined.std(axis=0),
            "shape": combined.shape,
            "n_replicas": len(self.samples),
        }
