"""Utility functions for configuration management and validation."""

import json
from pathlib import Path
from typing import Any, TypeVar

import numpy as np
from pydantic import BaseModel, ValidationError

from .config import SimulationConfig
from .models import (
    SimulationResult,
)

T = TypeVar("T", bound=BaseModel)


def load_config_from_json(  # noqa: UP047
    file_path: str | Path,
    config_class: type[T] = SimulationConfig,  # type: ignore[assignment]
) -> T:
    """
    Load configuration from a JSON file.

    Args:
        file_path: Path to the JSON configuration file
        config_class: Pydantic model class to deserialize into (SimulationConfig, ControllerConfig, or ControllerModel)

    Returns:
        Validated configuration object

    Raises:
        ValidationError: If the configuration is invalid
        FileNotFoundError: If the file doesn't exist
        json.JSONDecodeError: If the JSON is malformed
    """

    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {file_path}")

    with open(file_path) as f:
        data = json.load(f)

    # Convert lists back to numpy arrays for matrices/vectors
    data = _convert_lists_to_arrays(data)

    try:
        return config_class(**data)
    except ValidationError as e:
        raise ValidationError(f"Invalid configuration in {file_path}: {e}") from e


def save_config_to_json(config: SimulationConfig, file_path: str | Path) -> None:
    """
    Save configuration to a JSON file.

    Args:
        config: SimulationConfig object to save
        file_path: Path where to save the JSON file
    """
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    # Convert to dict and handle numpy arrays
    data = config.model_dump()
    data = _convert_arrays_to_lists(data)

    with open(file_path, "w") as f:
        json.dump(data, f, indent=2)


def save_results_to_json(results: SimulationResult, file_path: str | Path) -> None:
    """
    Save simulation results to a JSON file.

    Args:
        results: Results object to save
        file_path: Path where to save the JSON file
    """
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    # Convert to dict and handle numpy arrays
    data = results.model_dump()
    data = _convert_arrays_to_lists(data)

    with open(file_path, "w") as f:
        json.dump(data, f, indent=2)


def validate_config(config_dict: dict[str, Any]) -> tuple[bool, list[str]]:
    """
    Validate a configuration dictionary without creating the object.

    Args:
        config_dict: Dictionary containing configuration data

    Returns:
        Tuple of (is_valid, list_of_error_messages)
    """
    try:
        # Convert lists to arrays if needed
        processed_dict = _convert_lists_to_arrays(config_dict)

        # Try to validate as SimulationConfig (top level)
        SimulationConfig(**processed_dict)

        return True, []
    except ValidationError as e:
        errors = []
        for error in e.errors():
            loc = " -> ".join(str(x) for x in error["loc"])
            errors.append(f"{loc}: {error['msg']}")
        return False, errors
    except Exception as e:
        return False, [f"Unexpected error: {str(e)}"]


def _convert_lists_to_arrays(data: Any) -> Any:
    """Recursively convert lists to numpy arrays where appropriate."""
    if isinstance(data, dict):
        # Convert specific keys that should be numpy arrays
        array_keys = {"coupling_matrix", "external_field"}
        result = {}
        for key, value in data.items():
            if key in array_keys and isinstance(value, list):
                result[key] = np.array(value, dtype=np.float64)
            else:
                result[key] = _convert_lists_to_arrays(value)
        return result
    elif isinstance(data, list):
        return [_convert_lists_to_arrays(item) for item in data]
    else:
        return data


def _convert_arrays_to_lists(data: Any) -> Any:
    """Recursively convert numpy arrays to lists for JSON serialization."""
    if isinstance(data, np.ndarray):
        return data.tolist()
    elif isinstance(data, (np.integer, np.floating)):
        # Convert numpy scalar types to Python native types
        return data.item()
    elif isinstance(data, dict):
        return {key: _convert_arrays_to_lists(value) for key, value in data.items()}
    elif isinstance(data, list):
        return [_convert_arrays_to_lists(item) for item in data]
    elif isinstance(data, set):
        return list(data)  # Convert sets to lists for JSON
    else:
        return data
