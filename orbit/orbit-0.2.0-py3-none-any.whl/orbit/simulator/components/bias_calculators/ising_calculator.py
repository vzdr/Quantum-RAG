import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from ...types import Bit, Matrix, Vector
from ..base import AbstractBiasCalculator


class IsingBiasCalculatorModel(BaseModel):
    """Specific configuration for Ising model bias calculator."""

    calculator_type: str = Field(
        default="Ising", frozen=True, description="Calculator type"
    )
    coupling_matrix: Matrix = Field(..., description="Coupling matrix J between p-bits")
    external_field: Vector = Field(..., description="External magnetic field h")

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_validator("coupling_matrix")
    @classmethod
    def validate_coupling_matrix(cls, v: np.ndarray) -> np.ndarray:
        """Validate coupling matrix properties."""
        if v.ndim != 2:
            raise ValueError("Coupling matrix must be 2-dimensional")

        if v.shape[0] != v.shape[1]:
            raise ValueError("Coupling matrix must be square")

        return v

    @field_validator("external_field")
    @classmethod
    def validate_external_field(cls, v: np.ndarray) -> np.ndarray:
        """Validate external field vector."""
        if v.ndim != 1:
            raise ValueError("External field must be 1-dimensional")

        return v

    @model_validator(mode="after")
    def validate_dimensions(self) -> "IsingBiasCalculatorModel":
        """Validate dimensional consistency."""
        matrix_size = self.coupling_matrix.shape[0]
        field_size = len(self.external_field)

        if matrix_size != field_size:
            raise ValueError(
                f"Coupling matrix size ({matrix_size}) must match "
                f"external field size ({field_size})"
            )

        return self


class IsingCalculator(AbstractBiasCalculator):
    """Bias calculator for Ising model simulations."""

    def __init__(self, J: Matrix, h: Vector) -> None:
        """
        Initialize the Ising bias calculator with coupling matrix J and external field h.

        Args:
            J (Matrix): Coupling matrix between p-bits.
            h (Vector): External magnetic field vector.
        """
        # Validate inputs using Pydantic model
        model = IsingBiasCalculatorModel(coupling_matrix=J, external_field=h)

        self._J = model.coupling_matrix
        self._h = model.external_field

    def calculate_bias(self, index: int, neighbor_samples: dict[int, Bit]) -> float:
        """
        Calculate the bias for a given p-bit based on its neighbors' samples.

        Args:
            index (int): Index of the p-bit for which to calculate the bias.
            neighbor_samples (dict[int, Bit]): Dictionary mapping neighbor indices to their sampled states (0 or 1).

        Returns:
            float: Calculated bias for the specified p-bit.
        """
        bias = float(self._h[index])
        for neighbor_index, sample in neighbor_samples.items():
            bias += float(self._J[index, neighbor_index] * (2 * sample - 1))

        return bias
