import math
import random
import warnings

import numpy as np

# TODO:
# - implement pbit clamping


class Pbit:
    """Probabilistic Bit (pbit) class."""

    def __init__(self, id: int | None = None, bias: float = 0.0):
        """
        Args:
            id (int | None): Unique identifier for the pbit. Defaults to None.
            bias (float): Bias value for the p-bit. Defaults to 0.
        """
        self._id = id
        self._bias = bias

    @property
    def id(self) -> int | None:
        """Getter for pbit ID"""
        return self._id

    @property
    def bias(self) -> float:
        """Getter for pbit bias"""
        return self._bias

    @bias.setter
    def bias(self, value: float) -> None:
        """Setter for pbit bias"""
        assert isinstance(value, (float, np.floating)), "Bias must be a float."
        self._bias = value

    def _activation_function(self) -> float:
        """
        Sigmoid activation function for the pbit.

        Returns:
            float: Probability of pbit being in '1' state.
        """
        return 1 / (1 + math.exp(-self.bias))

    def sample(self) -> int:
        """
        Sample the pbit state based on its activation function and current bias.

        Returns:
            int: 0 or 1 representing the pbit state.
        """
        prob = self._activation_function()
        return 1 if random.random() < prob else 0

    def __hash__(self):
        if self.id is None:
            warnings.warn(
                "Hashing a pbit with no ID may lead to unexpected behavior.",
                stacklevel=2,
            )
        return hash(self.id)

    def __eq__(self, other):
        if self.id is None:
            warnings.warn(
                "Checking equivalence of a pbit with no ID may lead to unexpected behavior.",
                stacklevel=2,
            )
        return isinstance(other, Pbit) and self.id == other.id

    def __repr__(self):
        return f"Pbit(id={self.id}, bias={self.bias})"
