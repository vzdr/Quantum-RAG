import os
import time

import numpy as np

from ...utils.logging import configure_logging, get_logger
from ..config import SimulationConfig
from ..models import SimulationModel, SimulationResult
from .controller import Controller


class Simulator:
    def __init__(self, model: SimulationModel, config: SimulationConfig):
        self.config = config
        self.log_level = config.log_level
        self.log_file = config.log_file
        self.random_seed = config.random_seed
        self.controller_config = config.controller_config
        self.model = model
        self.controller_model = self.model.controller_model

        configure_logging(
            level=self.log_level, enable_console=True, log_file=self.log_file
        )
        self.logger = get_logger("simulator")

        # Set random seed if specified
        if self.random_seed is not None:
            np.random.seed(config.random_seed)
            self.logger.debug(f"Set random seed to {config.random_seed}")

    def _initialize(self):
        """Instantiate a fresh controller for the simulation."""
        self.controller = Controller(
            model=self.controller_model,
            config=self.controller_config,
        )

    def run(
        self,
        reset: bool = True,
    ) -> SimulationResult:
        """Run the simulation."""
        if reset:
            self.logger.debug(
                "Simulator starting fresh run; previous state if any will be discarded.",
                stacklevel=2,
            )
            self._initialize()
        else:
            self.logger.warning("Unintended continuation of previous simulation state.")

        self.logger.info("Simulation starting...")
        start_time = time.time()

        # Determine number of processes
        cpu_count = os.cpu_count() or 1  # Fallback to 1 if None
        max_processes = min(cpu_count, self.controller_config.max_processes)
        n_processes = min(max_processes, self.controller_config.n_replicas)

        # Run the controller
        samples = self.controller.run(n_processes)

        execution_time = time.time() - start_time

        # Stack samples from each replica
        samples = [np.stack(replica_samples) for replica_samples in samples]
        iterations = [
            replica.iteration_count for replica in self.controller.completed_replicas
        ]
        full_sweeps = [
            replica.full_sweep_count for replica in self.controller.completed_replicas
        ]
        parallel_bias_calculations = [
            replica.parallel_bias_calculation_count
            for replica in self.controller.completed_replicas
        ]

        # Create metadata
        metadata = {
            "n_processes_used": n_processes,
            "start_time": start_time,
        }

        # Log simulation completion summary
        self.logger.info(f"Simulation completed in {execution_time:.2f} seconds")

        return SimulationResult(
            samples=samples,
            metadata=metadata,
            total_iterations=iterations,
            full_sweeps=full_sweeps,
            parallel_bias_calculations=parallel_bias_calculations,
            execution_time=execution_time,
        )
