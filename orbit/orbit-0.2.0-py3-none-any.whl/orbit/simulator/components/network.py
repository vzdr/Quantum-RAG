import random

import numpy as np

from ..models import NetworkModel
from .pbit import Pbit

# TODO:
# - allow for initialization of pbits with specific biases
# - allow for initialization with clamped pbits
# - implement adiabatic network / allowing for p-bits to be added during execution
# - enable sampling update group weighted by ug size


class Network:
    """Network class representing a collection of pbits and their interconnections."""

    def __init__(self, model: NetworkModel):
        """
        Args:
            model (NetworkModel): The network model containing adjacency and update group information.
        """

        self.model = model
        self.update_groups_idx = self.model.update_groups

        self._n = len(self.model.adjacency)
        self.n_update_groups = max(self.update_groups_idx) + 1

        # Initialize pbits
        self._pbits = [Pbit(id=x) for x in range(self.n)]

        # Initialize adjacency
        self._adjacency: dict[Pbit, set[Pbit]] = {}
        for key, neighbors in self.model.adjacency.items():
            self._adjacency[self._pbits[key]] = {self._pbits[i] for i in neighbors}

        # Initialize update groups
        self._update_groups: list[set[Pbit]] = [
            set() for _ in range(self.n_update_groups)
        ]
        for i in range(self.n):
            self._update_groups[self.update_groups_idx[i]].add(self._pbits[i])
        self.largest_update_group_size = max(len(s) for s in self._update_groups)

    @property
    def n(self) -> int:
        """Getter for number of pbits in the network"""
        return self._n

    @property
    def adjacency(self) -> dict[Pbit, set[Pbit]]:
        """Getter for adjacency dictionary of the network"""
        return self._adjacency

    @property
    def update_groups(self) -> list[set[Pbit]]:
        """Getter for update groups of the network"""
        return self._update_groups

    def get_neighbors(self, pbit: Pbit) -> set[Pbit]:
        """
        Get the neighboring pbits of a given pbit.

        Args:
            pbit (Pbit): The pbit whose neighbors are to be retrieved.

        Returns:
            set[Pbit]: Set of neighboring pbits.
        """
        return self._adjacency[pbit]

    def get_update_group_neighbors(self, index: int) -> set[Pbit]:
        """
        Get all neighboring pbits for a given update group.

        Args:
            index (int): Index of the update group.
        Returns:
            set[Pbit]: Set of neighboring pbits for the specified update group.
        """
        ug = self._update_groups[index]
        neighbors = set()
        for pbit in ug:
            neighbors.update(self.get_neighbors(pbit))
        return neighbors

    def generate_update_group_order(self, previous: int | None):
        nums = list(range(self.n_update_groups))
        random.shuffle(nums)
        if previous is not None and self.n_update_groups > 1 and nums[0] == previous:
            swap_idx = random.randint(1, self.n_update_groups - 1)
            nums[0], nums[swap_idx] = nums[swap_idx], nums[0]
        return nums

    def sample_all_pbits(self) -> np.ndarray:
        """
        Sample all pbits in the network.

        Returns:
            np.ndarray: Array of sampled pbit states
        """
        return np.array([pbit.sample() for pbit in self._pbits], dtype=np.uint8)
