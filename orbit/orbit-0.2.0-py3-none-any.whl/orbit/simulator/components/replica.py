import math

import numpy as np

from ..config import ReplicaConfig
from ..models import NetworkModel
from .base import AbstractBiasCalculator
from .network import Network

# TODO: Add annealing schedules and advanced termination conditions?


class Replica:
    def __init__(
        self,
        id: int,
        bias_calculator: AbstractBiasCalculator,
        network_model: NetworkModel,
        config: ReplicaConfig,
    ):
        """
        Initialize a replica for probabilistic computing simulation.

        Args:
            id: Unique identifier for this replica
            network: The network of p-bits for this replica
            bias_calculator: Calculator for p-bit biases
            config: Configuration settings for the replica
        """
        self.id = id
        self.network = Network(network_model)
        self.bias_calculator = bias_calculator
        self.config = config

        self.n_bias_calculators: int | None = self.config.n_bias_calculators
        if self.n_bias_calculators is None:
            self.n_bias_calculators = self.network.largest_update_group_size

        self.beta = self.config.beta_initial
        self.beta_step_size = self.config.beta_step_size
        self.beta_step_interval = self.config.beta_step_interval

        self.iteration_count = 0
        self.full_sweep_count = 0
        self.parallel_bias_calculation_count = 0

        self.prev_ug = None
        self.samples: list[np.ndarray] = []

    def termination_condition(self) -> bool:
        """
        Check if the termination condition for the replica is met.

        Returns:
            bool: True if the termination condition is met, False otherwise.
        """
        return self.full_sweep_count >= self.config.max_full_sweeps

    def step(self):
        """Performs one full sweep of p-bit bias calculations"""

        ug_order = self.network.generate_update_group_order(self.prev_ug)

        for ug_index in ug_order:
            ug = self.network.update_groups[ug_index]

            # Sample each neighboring p-bit of the update group
            ug_neighbors = self.network.get_update_group_neighbors(ug_index)
            ug_neighbor_samples = {pbit.id: pbit.sample() for pbit in ug_neighbors}

            # Update each p-bit in the sampled update group
            for pbit in ug:
                neighbors = self.network.get_neighbors(pbit)
                neighbor_samples = {
                    neighbor.id: ug_neighbor_samples[neighbor.id]
                    for neighbor in neighbors
                }
                bias = self.bias_calculator.calculate_bias(pbit.id, neighbor_samples)
                pbit.bias = self.beta * bias

            self.parallel_bias_calculation_count += math.ceil(
                len(ug) / self.n_bias_calculators
            )
            self.samples.append(self.network.sample_all_pbits())

        self.iteration_count += self.network.n_update_groups
        self.full_sweep_count += 1

        self.prev_ug = ug_order[-1]

        # Update Beta
        if self.full_sweep_count % self.beta_step_interval == 0:
            self.beta += self.beta_step_size
