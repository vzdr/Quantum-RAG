import threading
from multiprocessing import Manager, Pool, current_process
from typing import Any

from ...utils.logging import get_logger, is_info_enabled
from ..config import ControllerConfig
from ..models import ControllerModel
from .replica import Replica


# Standalone function for multiprocessing
def _run_replica(args: tuple[Replica, Any, bool]) -> Replica:
    replica, state_queue, should_log = args
    while not replica.termination_condition():
        replica.step()
        # Only send progress updates if logging is actually enabled
        if should_log and replica.full_sweep_count % 10_000 == 0:
            proc = current_process()
            state_queue.put(
                (replica.id, replica.full_sweep_count, replica.beta, proc.pid)
            )

    return replica


class Controller:
    def __init__(
        self,
        model: ControllerModel,
        config: ControllerConfig,
    ):
        """
        Initialize Controller with Pydantic configuration.

        Args:
            model: Controller model containing network and bias calculator
            config: Controller configuration with replica settings
        """
        self.model = model
        self.config = config
        self.n_replicas = self.config.n_replicas
        self.max_processes = self.config.max_processes

        self.logger = get_logger("controller")

        bias_calculator = self.model.bias_calculator_model.instantiate()
        # Create replicas
        self.replicas = [
            Replica(
                id=i,
                bias_calculator=bias_calculator,
                network_model=self.model.network_model,
                config=self.config.replica_config,
            )
            for i in range(self.n_replicas)
        ]

        self.manager = Manager()
        self.state_queue = self.manager.Queue()

        self.logger.debug("Reset all replicas")

    def run(self, n_processes: int) -> list:
        """
        Run the simulation and return raw results.

        Args:
            n_processes: Number of processes to use for parallel execution

        Returns:
            Tuple of (samples, total_iterations)
        """
        # Check once if we should log progress updates
        should_log_progress = is_info_enabled("controller")

        def log_updates():
            while True:
                try:
                    replica_id, full_sweep_count, beta, pid = self.state_queue.get(
                        timeout=1
                    )
                    # Log immediately since we already checked if logging is enabled
                    self.logger.info(
                        f"Replica {replica_id}: full_sweep_count {full_sweep_count}, beta={beta:.3f}, PID={pid}"
                    )
                except Exception:
                    break

        args = [
            (replica, self.state_queue, should_log_progress)
            for replica in self.replicas
        ]

        # Only start logging thread if we're actually going to log
        if should_log_progress:
            consumer_thread = threading.Thread(target=log_updates, daemon=True)
            consumer_thread.start()

        with Pool(processes=n_processes) as pool:
            self.completed_replicas = pool.map(_run_replica, args)
        # Clean up logging thread if it was started
        if should_log_progress:
            consumer_thread.join(timeout=1)

        # Extract raw results
        samples = [replica.samples for replica in self.completed_replicas]

        return samples
