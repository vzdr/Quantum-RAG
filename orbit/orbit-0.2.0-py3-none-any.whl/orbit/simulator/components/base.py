from abc import ABC, abstractmethod

from ..types import Bit


class AbstractBiasCalculator(ABC):
    @abstractmethod
    def calculate_bias(self, index: int, neighbor_samples: dict[int, Bit]) -> float:
        """
        Calculate the bias for a given p-bit based on its neighbors' samples.

        Args:
            index (int): Index of the p-bit for which to calculate the bias.
            neighbor_samples (dict[int, Bit]): Dictionary mapping neighbor indices to their sampled states (0 or 1).

        Returns:
            float: Calculated bias for the specified p-bit.
        """
