from typing import Annotated, Any, Literal

import numpy as np
from numpy.typing import NDArray

# Core mathematical types
Matrix = Annotated[NDArray[np.float64], "shape=(n,n)"]
Vector = Annotated[NDArray[np.float64], "shape=(n,)"]
Bit = Literal[0, 1]

# Network topology types
NodeId = int
AdjacencyDict = dict[NodeId, set[NodeId]]
UpdateGroups = list[int]

# Configuration types
ConfigDict = dict[str, Any]
ParameterDict = dict[str, float | int | str | bool]

# Sample and state types
Sample = NDArray[np.uint8]  # Single sample from all pbits
SampleBatch = list[Sample]  # Multiple samples
ReplicaSamples = list[Sample]  # Samples from one replica

# Energy and bias types
Energy = float
Bias = float
BiasDict = dict[NodeId, Bias]

# Result types
ConvergenceData = dict[str, float | int | bool]
Metadata = dict[str, Any]

# Pydantic-compatible types for validation
PydanticMatrix = Matrix | list[list[float]]  # Allow lists for JSON
PydanticVector = Vector | list[float]  # Allow lists for JSON
