"""Pydantic configuration models for the ORBIT simulator."""

from pydantic import BaseModel, ConfigDict, Field, field_validator

from ..utils.logging import LogLevel


class ReplicaConfig(BaseModel):
    """Configuration for individual replica."""

    max_full_sweeps: int = Field(
        default=1000, gt=0, description="Maximum number of full sweeps per replica"
    )
    beta_step_size: float = Field(
        default=0.003, ge=0, description="Beta increment per interval"
    )
    beta_step_interval: int = Field(
        default=1,
        gt=0,
        description="Number of steps / full sweeps between beta increments",
    )
    beta_initial: float | None = Field(
        default=1.0, gt=0, description="Initial beta value for annealing schedules"
    )
    n_bias_calculators: int | None = Field(
        default=None, gt=0, description="Number of bias calculators per replica"
    )


class ControllerConfig(BaseModel):
    """Configuration for controller"""

    n_replicas: int = Field(default=1, gt=0, description="Number of replicas")

    max_processes: int = Field(
        default=4, gt=0, description="Number of processes to compute replicas"
    )

    replica_config: ReplicaConfig = Field(
        ..., description="Configuration for individual replicas"
    )

    @field_validator("n_replicas")
    @classmethod
    def validate_n_replicas(cls, v: int) -> int:
        """Validate number of replicas."""
        if v > 1000:  # Reasonable upper limit
            raise ValueError("Number of replicas should not exceed 1000")
        return v


class SimulationConfig(BaseModel):
    """Main configuration for ORBIT simulations."""

    controller_config: ControllerConfig = Field(
        ..., description="Controller configuration"
    )

    # Execution settings
    log_level: LogLevel = Field(
        default=LogLevel.INFO, description="Logging level for simulation output"
    )
    log_file: str | None = Field(
        default=None, description="Optional file path for logging output"
    )
    random_seed: int | None = Field(
        default=None, description="Random seed for reproducibility"
    )

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        # Note: json_encoders are deprecated in Pydantic v2
        # Use model_dump() with custom serializer instead
    )
