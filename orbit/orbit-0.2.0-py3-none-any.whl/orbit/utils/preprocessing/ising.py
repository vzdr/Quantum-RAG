import numpy as np


def generate_adjacency(J: np.ndarray) -> dict[int, set[int]]:
    """
    Generate network adjacency in the form {pbit_id: {neighbor_pbit_id, ...}, ...} from the J matrix

    Args:
        J (np.ndarray): An nxn symmetric matrix representing the interactions between spin sites

    Returns:
        dict[int, set[int]]: Network adjacency

    """
    adjacency = {}
    n = J.shape[0]
    for i in range(n):
        neighbors = set()
        for j, val in enumerate(J[i]):
            if val != 0:
                neighbors.add(j)
        adjacency[i] = neighbors

    return adjacency


def generate_update_groups(adjacency: dict[int, set[int]]) -> np.ndarray:
    """
    Assign update groups via greedy graph coloring

    Args:
        adjacency (dict[int, set[int]]): Network adjacency

    Returns:
        np.ndarray: n-array of allocated update groups
    """
    update_groups = np.full(len(adjacency), -1, dtype="int16")
    for i, neighbors in adjacency.items():
        neighbor_colors = set()
        for neighbor_idx in neighbors:
            if update_groups[neighbor_idx] != -1:
                neighbor_colors.add(update_groups[neighbor_idx])
        active_color = 0
        while active_color in neighbor_colors:
            active_color += 1
        update_groups[i] = active_color

    return update_groups
