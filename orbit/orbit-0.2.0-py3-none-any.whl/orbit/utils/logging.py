"""
Logging utilities for the ORBIT simulation framework.

This module provides centralized logging configuration with performance-optimized
handlers for simulation environments.
"""

import logging
import sys
from datetime import datetime
from enum import Enum
from pathlib import Path


class LogLevel(str, Enum):
    """Log level enumeration compatible with Pydantic."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class OrbitLogger:
    """Centralized logger configuration for ORBIT components."""

    _loggers: dict[str, logging.Logger] = {}
    _configured: bool = False
    _current_log_file: str | None = None

    @classmethod
    def get_logger(cls, name: str) -> logging.Logger:
        """
        Get or create a logger for the specified component.

        Args:
            name: Logger name (typically module name)

        Returns:
            Configured logger instance
        """
        if name not in cls._loggers:
            logger = logging.getLogger(f"orbit.{name}")
            cls._loggers[name] = logger

            # Configure if not already done
            if not cls._configured:
                cls.configure()

        return cls._loggers[name]

    @classmethod
    def configure(
        cls,
        level: LogLevel = LogLevel.INFO,
        format_string: str | None = None,
        enable_console: bool = True,
        log_file: str | None = None,
    ) -> None:
        """
        Configure global logging settings for ORBIT.

        This only configures once. Subsequent calls are ignored to avoid
        reconfiguration overhead in multi-Controller scenarios.

        Args:
            level: Minimum log level to display
            format_string: Custom log format (uses default if None)
            enable_console: Whether to log to console
            log_file: Optional file path for log output
        """
        if cls._configured:
            # Already configured, ignore subsequent calls
            return

        # Default format with timestamp and level
        if format_string is None:
            format_string = "[%(asctime)s] %(levelname)s - %(name)s: %(message)s"

        formatter = logging.Formatter(format_string, datefmt="%Y-%m-%d %H:%M:%S")

        # Configure root orbit logger
        root_logger = logging.getLogger("orbit")
        root_logger.setLevel(getattr(logging, level.value))

        # Clear any existing handlers
        root_logger.handlers.clear()

        # Console handler
        if enable_console:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            console_handler.setLevel(getattr(logging, level.value))
            root_logger.addHandler(console_handler)

        # File handler (optional)
        if log_file:
            # Create logs directory if it doesn't exist
            log_path = cls._prepare_log_file_path(log_file)
            cls._current_log_file = log_path
            file_handler = logging.FileHandler(log_path)
            file_handler.setFormatter(formatter)
            file_handler.setLevel(getattr(logging, level.value))
            root_logger.addHandler(file_handler)

        # Prevent propagation to avoid duplicate logs
        root_logger.propagate = False

        cls._configured = True

    @classmethod
    def set_level(cls, level: LogLevel) -> None:
        """
        Update the logging level for all ORBIT loggers.

        Args:
            level: New minimum log level
        """
        numeric_level = getattr(logging, level.value)

        # Update root logger and all handlers
        root_logger = logging.getLogger("orbit")
        root_logger.setLevel(numeric_level)

        for handler in root_logger.handlers:
            handler.setLevel(numeric_level)

    @classmethod
    def is_enabled_for(cls, name: str, level: LogLevel) -> bool:
        """
        Check if logging is enabled for a specific level without creating log record.

        This is a performance optimization for hot code paths.

        Args:
            name: Logger name
            level: Log level to check

        Returns:
            True if the logger would emit a message at this level
        """
        logger = cls.get_logger(name)
        return logger.isEnabledFor(getattr(logging, level.value))

    @classmethod
    def _prepare_log_file_path(cls, log_file: str) -> str:
        """
        Prepare the log file path with timestamp and ensure logs directory exists.

        Args:
            log_file: Base filename for the log file

        Returns:
            Full path to the log file with timestamp
        """
        # Create logs directory
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)

        # Add timestamp to filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Handle file extension
        path = Path(log_file)
        if path.suffix:
            # If has extension, insert timestamp before extension
            base_name = path.stem
            extension = path.suffix
            timestamped_name = f"{base_name}_{timestamp}{extension}"
        else:
            # If no extension, add .log extension with timestamp
            timestamped_name = f"{log_file}_{timestamp}.log"

        return str(logs_dir / timestamped_name)

    @classmethod
    def get_current_log_file(cls) -> str | None:
        """
        Get the path to the current log file if file logging is enabled.

        Returns:
            Path to current log file or None if file logging is disabled
        """
        return cls._current_log_file

    @classmethod
    def reset(cls) -> None:
        """Reset all logging configuration (mainly for testing)."""
        cls._loggers.clear()
        cls._configured = False
        cls._current_log_file = None

        # Clear all orbit loggers
        root_logger = logging.getLogger("orbit")
        root_logger.handlers.clear()
        root_logger.setLevel(logging.NOTSET)


# Convenience functions for common usage patterns
def get_logger(name: str) -> logging.Logger:
    """Get a logger for the specified component name."""
    return OrbitLogger.get_logger(name)


def configure_logging(
    level: LogLevel = LogLevel.INFO,
    format_string: str | None = None,
    enable_console: bool = True,
    log_file: str | None = None,
) -> None:
    """Configure global logging settings (only once)."""
    OrbitLogger.configure(level, format_string, enable_console, log_file)


def set_log_level(level: LogLevel) -> None:
    """Update the global logging level."""
    OrbitLogger.set_level(level)


def is_debug_enabled(name: str) -> bool:
    """Fast check if debug logging is enabled (for performance-critical code)."""
    return OrbitLogger.is_enabled_for(name, LogLevel.DEBUG)


def is_info_enabled(name: str) -> bool:
    """Fast check if info logging is enabled (for performance-critical code)."""
    return OrbitLogger.is_enabled_for(name, LogLevel.INFO)


def get_current_log_file() -> str | None:
    """Get the path to the current log file if file logging is enabled."""
    return OrbitLogger.get_current_log_file()
