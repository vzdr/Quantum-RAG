import numpy as np


def binary_array_to_int(binary_array: np.ndarray) -> int:
    """
    Convert binary array to integer

    Args:
        binary_array (np.ndarray): Binary array in big endian format

    Returns:
        int: The corresponding integer
    """
    return int(binary_array.dot(1 << np.arange(binary_array.size)[::-1]))


def int_to_binary_array(n: int, length: int = None) -> np.ndarray:
    """
    Convert integer to binary array

    Args:
        n (int): Integer to be converted
        length (int): Length of array / number of bits

    Returns:
        np.ndarray: Big endian binary array
    """
    if length is None:
        length = n.bit_length() or 1
    powers = 1 << np.arange(length - 1, -1, -1)
    return ((n & powers) > 0).astype(np.uint8)
