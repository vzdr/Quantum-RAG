from typing import Any, Literal

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

# TODO: Address this import, possibly relocate SimulationResult model
from ...simulator.models import SimulationResult
from .utils import binary_array_to_int, int_to_binary_array


class IsingResult(BaseModel):
    backend: Literal["SIMULATOR", "EMULATOR", "HARDWARE"] = Field(
        frozen=True, description="ORBIT backend"
    )
    samples_raw: list[np.ndarray] = Field(
        frozen=True, description="Samples from each replica"
    )
    metadata: dict[str, Any] = Field(
        frozen=True, default_factory=dict, description="Additional metadata"
    )
    iterations: list[int] | None = Field(
        default=None, description="Iterations completed by each replica"
    )
    full_sweeps: list[int] | None = Field(
        default=None, description="Full sweeps completed by each replica"
    )
    parallel_bias_calculations: list[int] | None = Field(
        default=None,
        description="Number of parallel bias calculations completed by each replica",
    )
    execution_time: float | None = Field(
        default=None, description="Total execution time in seconds"
    )

    samples: dict[int, dict[str, float | int]] = Field(
        default=None, description="Processed samples"
    )
    min_state: np.ndarray = Field(default=None, description="State with minimum energy")
    min_cost: float = Field(
        default=None, description="Minimum energy found during execution"
    )
    model_config = ConfigDict(arbitrary_types_allowed=True)


def calculate_state_ising_energy(state: np.ndarray, J: np.ndarray, h: np.ndarray):
    """
    Calculate energy / cost of a given state

    Args:
        state (np.ndarray): A binary n-array representing a given state
        J (np.ndarray): An nxn symmetric matrix representing the interactions between spin sites
        h (np.ndarray): An n-array representing the external field applied to each spin site

    Returns:
        float: The energy / cost of the state
    """
    s = 2 * np.array(state, dtype=int) - 1
    return float(s @ (J @ s) + h @ s)


def process_samples(samples: list[np.ndarray], J: np.ndarray, h: np.ndarray):
    """
    Calculate energy / cost of a given state

    Args:
        samples (list[np.ndarray]): A list of 2D arrays, each replica reports a list of sample states
        J (np.ndarray): An nxn symmetric matrix representing the interactions between spin sites
        h (np.ndarray): An n-array representing the external field applied to each spin site

    Returns:
        float: The energy / cost of the state
    """
    sample_dict = {}
    for replica_samples in samples:
        for sample in replica_samples:
            sample_id = binary_array_to_int(sample)
            entry = sample_dict.setdefault(
                sample_id,
                {"count": 0, "cost": calculate_state_ising_energy(sample, J, h)},
            )
            entry["count"] += 1

    return sample_dict


def postprocess_simulator(result: SimulationResult, J: np.ndarray, h: np.ndarray):
    """
    Perform processing on the results of the simulator

    Args:
        result (SimulationResult): A list of 2D arrays, each replica reports a list of sample states
        J (np.ndarray): An nxn symmetric matrix representing the interactions between spin sites
        h (np.ndarray): An n-array representing the external field applied to each spin site

    Returns:
        float: The energy / cost of the state
    """

    processed_samples = process_samples(result.samples, J, h)
    min_id = min(processed_samples, key=lambda k: processed_samples[k]["cost"])
    min_state = int_to_binary_array(min_id, length=len(h))
    min_cost = processed_samples[min_id]["cost"]

    return IsingResult(
        backend="SIMULATOR",
        samples_raw=result.samples,
        metadata=result.metadata,
        iterations=result.iterations,
        full_sweeps=result.full_sweeps,
        parallel_bias_calculations=result.parallel_bias_calculations,
        execution_time=result.execution_time,
        samples=processed_samples,
        min_state=min_state,
        min_cost=min_cost,
    )
