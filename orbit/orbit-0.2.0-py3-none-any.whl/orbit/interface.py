from enum import Enum

import numpy as np

from .simulator.components.bias_calculators.ising_calculator import IsingCalculator
from .simulator.components.simulator import Simulator
from .simulator.config import ControllerConfig, ReplicaConfig, SimulationConfig
from .simulator.models import (
    BiasCalculatorModel,
    ControllerModel,
    NetworkModel,
    SimulationModel,
)
from .utils.postprocessing.ising import postprocess_simulator
from .utils.preprocessing.ising import generate_adjacency, generate_update_groups


class Backend(str, Enum):
    """Backend enumeration"""

    SIMULATOR = "SIMULATOR"
    EMULATOR = "EMULATOR"
    HARDWARE = "HARDWARE"


def optimize_ising(
    J: np.ndarray,
    h: np.ndarray,
    backend: Backend = "SIMULATOR",
    full_sweeps: int = 1_000,
    n_replicas: int = 1,
    max_processes: int = 4,
    beta_initial: float = 1.0,
    beta_end: float = 1.0,
    beta_step_interval: int = 1,
    n_bias_calculators_per_replica: int | None = None,
    random_seed: int | None = None,
):
    """
    Finds the ground state of an Ising model

    Args:
        J (np.ndarray): An nxn symmetric matrix representing the interactions between spin sites
        h (np.ndarray): An n-array representing the external field applied to each spin site
        backend (Backend): ORBIT backend to use
        full_sweeps (int): The maximum number of full sweeps (every p-bit in the system updating its bias) before terminating
        n_replicas (int): The number of replicated instances to run
        max_processes (int): The max number of processes used to execute replicas, limited by cpu core count
        beta_initial (float): Start value of beta (inverse system temperature) for linear cooling scheme
        beta_end (float): End value of beta
        beta_step_interval (int): Number of full sweeps to occur before increasing beta
        n_bias_calculators_per_replica (int | None): Optional limit on the number of bias calculators each replica has access to
        random_seed (int | None): Optional randomness seed for simulator and emulator

    Returns:
        IsingResult: Contains results including raw data, metadata, and found minima

    """
    # TODO: Assert J and h shape

    beta_step_size = ((beta_end - beta_initial) / full_sweeps) * beta_step_interval

    adjacency = generate_adjacency(J)
    update_groups = generate_update_groups(adjacency)

    if backend == Backend.SIMULATOR:
        network_model = NetworkModel(adjacency=adjacency, update_groups=update_groups)
        bias_calculator_model = BiasCalculatorModel(
            calculator_class=IsingCalculator,
            calculator_args=(J, h),
            calculator_kwargs={},
        )
        controller_model = ControllerModel(
            bias_calculator_model=bias_calculator_model, network_model=network_model
        )
        simulation_model = SimulationModel(controller_model=controller_model)
        replica_config = ReplicaConfig(
            max_full_sweeps=full_sweeps,
            beta_initial=beta_initial,
            beta_step_size=beta_step_size,
            beta_step_interval=beta_step_interval,
            n_bias_calculators=n_bias_calculators_per_replica,
        )
        controller_config = ControllerConfig(
            n_replicas=n_replicas,
            max_processes=max_processes,
            replica_config=replica_config,
        )
        simulation_config = SimulationConfig(
            controller_config=controller_config, random_seed=random_seed
        )
        sim = Simulator(simulation_model, simulation_config)
        sim_results = sim.run()
        result = postprocess_simulator(sim_results, J, h)
        return result
    elif backend == Backend.EMULATOR:
        raise NotImplementedError()
    elif backend == Backend.HARDWARE:
        raise NotImplementedError()
    else:
        raise ValueError(f"Unsupported backend: {backend}")
