"""ORBIT: Probabilistic Computing Platform.

A comprehensive simulator, emulator, and hardware interface for Quantum Dice's
ORBIT probabilistic computing platform.

This package provides:
- Simulator: Simulate probabilistic computing models
- Emulator: Emulate ORBIT hardware behavior
- Interface: Interact with physical ORBIT hardware
- Utils: Common utilities and helper functions

Example:
    >>> import orbit
    >>> print(f"ORBIT version: {orbit.__version__}")
"""

from importlib.metadata import version as _version

from . import emulator, hardware_interface, simulator, utils
from .interface import optimize_ising

try:
    __version__ = _version("orbit")
except Exception:
    __version__ = "0.0.1"

__all__ = [
    "__version__",
    "emulator",
    "hardware_interface",
    "simulator",
    "utils",
    "optimize_ising",
]
